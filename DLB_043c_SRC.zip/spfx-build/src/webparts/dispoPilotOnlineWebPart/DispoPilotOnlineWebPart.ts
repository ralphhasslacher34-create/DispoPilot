import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { staticHtml, bootDispoPilot } from './app-runtime';
import { SPHttpClient } from '@microsoft/sp-http';

export interface IDispoPilotOnlineWebPartProps {}

export default class DispoPilotOnlineWebPart extends BaseClientSideWebPart<IDispoPilotOnlineWebPartProps> {
  public render(): void {
    
  
  
  /* eslint-disable */
  // DP_V1_TESTDATA_BRIDGE_BEGIN
  const dpTestWindow: any = window as any;
  if (!dpTestWindow.__DISPOPILOT_TESTDATA_BRIDGE_V1) {
    dpTestWindow.__DISPOPILOT_TESTDATA_BRIDGE_V1 = true;
    const dpTestContext: any = this.context as any;
    const dpTestDom: HTMLElement = this.domElement;
    const dpEsc = (s: string): string => String(s || '').replace(/'/g, "''");
    const dpWebUrl = (): string => String(dpTestContext.pageContext.web.absoluteUrl || '').replace(/\/$/, '');
    const dpJsonHeaders: any = { 'Accept':'application/json;odata=nometadata', 'Content-Type':'application/json;odata=nometadata' };
    const dpWithTimeout = async (promise: Promise<any>, label: string, ms: number = 45000): Promise<any> => {
      let timer: any;
      try{
        return await Promise.race([
          promise,
          new Promise<any>((resolve,reject)=>{void resolve;timer=setTimeout(()=>reject(new Error(label+' – Zeitüberschreitung')),ms);})
        ]);
      } finally { if(timer)clearTimeout(timer); }
    };
    const dpGet = async (url: string): Promise<any> => {
      const r: any = await dpWithTimeout(
        dpTestContext.spHttpClient.get(url, SPHttpClient.configurations.v1, { headers:{'Accept':'application/json;odata=nometadata','Cache-Control':'no-cache'} }),
        'GET',45000
      );
      if (!r.ok) throw new Error(`GET ${r.status}: ${(await r.text()).slice(0,500)}`);
      return r.json();
    };
    const dpPost = async (url: string, body: any, headers?: any): Promise<any> => {
      const r: any = await dpWithTimeout(
        dpTestContext.spHttpClient.post(url, SPHttpClient.configurations.v1, {
          headers:{...dpJsonHeaders,...(headers||{})},
          body: typeof body==='string'?body:JSON.stringify(body)
        }),
        'POST',45000
      );
      if (!r.ok) throw new Error(`POST ${r.status}: ${(await r.text()).slice(0,700)}`);
      const txt=await r.text();
      return txt?JSON.parse(txt):{};
    };
    const dpDelete = async (url: string): Promise<void> => {
      const r: any = await dpWithTimeout(
        dpTestContext.spHttpClient.post(url, SPHttpClient.configurations.v1, {
          headers:{'Accept':'application/json;odata=nometadata','IF-MATCH':'*','X-HTTP-Method':'DELETE'}
        }),
        'DELETE',45000
      );
      if(!r.ok && r.status!==404)throw new Error(`DELETE ${r.status}: ${(await r.text()).slice(0,500)}`);
    };
    const dpSleep = (ms: number): Promise<void> => new Promise<void>((resolve)=>setTimeout(resolve,ms));
    const dpListExists = async (title: string): Promise<boolean> => {
      const url=`${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(title)}')?$select=Id`;
      const r: any=await dpWithTimeout(
        dpTestContext.spHttpClient.get(url,SPHttpClient.configurations.v1,{headers:{'Accept':'application/json;odata=nometadata'}}),
        'Liste '+title,45000
      );
      if(r.status===404)return false;
      if(!r.ok)throw new Error(`Liste ${title}: ${r.status} ${(await r.text()).slice(0,350)}`);
      return true;
    };
    const dpWaitList = async (title: string): Promise<void> => {
      for(let i=0;i<40;i++){
        if(await dpListExists(title))return;
        await dpSleep(500);
      }
      throw new Error('Liste '+title+' wurde nach dem Anlegen nicht rechtzeitig verfügbar.');
    };
    const dpWaitListGone = async (title: string): Promise<void> => {
      for(let i=0;i<40;i++){
        if(!(await dpListExists(title)))return;
        await dpSleep(500);
      }
      throw new Error('Alte Liste '+title+' wurde nicht rechtzeitig entfernt.');
    };
    const dpFieldKey = (s: string): string => String(s||'')
      .replace(/_x005f_/gi,'_')
      .replace(/\s+/g,'_')
      .toLowerCase();
    const dpFields = async (list: string): Promise<any[]> => {
      const j=await dpGet(`${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(list)}')/fields?$select=Title,InternalName,TypeAsString,Hidden&$top=5000`);
      return Array.isArray(j.value)?j.value:[];
    };
    const dpDiscoverSchema = async (list: string): Promise<any> => {
      const fields=await dpFields(list);
      const findField=(wanted:string):any=>{
        const key=dpFieldKey(wanted);
        return fields.find((f:any)=>dpFieldKey(f.Title)===key)
          || fields.find((f:any)=>dpFieldKey(f.InternalName)===key);
      };
      const typ=findField('DP_Typ');
      const daten=findField('DP_Daten');
      if(!typ||!daten){
        const diag=fields
          .filter((f:any)=>!f.Hidden)
          .map((f:any)=>`${String(f.Title||'')} [${String(f.InternalName||'')}]`)
          .slice(0,40).join(', ');
        throw new Error(`Datenfelder in ${list} nicht gefunden. Vorhanden: ${diag}`);
      }
      return {
        typTitle:String(typ.Title||'DP_Typ'),
        typInternal:String(typ.InternalName||''),
        typType:String(typ.TypeAsString||'Text'),
        dataTitle:String(daten.Title||'DP_Daten'),
        dataInternal:String(daten.InternalName||''),
        dataType:String(daten.TypeAsString||'Note')
      };
    };
    const dpEnsureFieldExact = async (
      list:string, displayTitle:string, internalName:string, typeAsString:string
    ):Promise<void> => {
      let fields=await dpFields(list);
      if(fields.some((f:any)=>String(f.InternalName||'')===internalName)){
        const f=fields.find((x:any)=>String(x.InternalName||'')===internalName);
        if(f && String(f.Title||'')!==displayTitle){
          await dpPost(
            `${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(list)}')/fields/getbyinternalnameortitle('${dpEsc(internalName)}')`,
            {Title:displayTitle},
            {'IF-MATCH':'*','X-HTTP-Method':'MERGE'}
          );
        }
        return;
      }
      const isNote=String(typeAsString||'').toLowerCase()==='note';
      await dpPost(
        `${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(list)}')/fields`,
        {Title:internalName,FieldTypeKind:isNote?3:2}
      );
      for(let i=0;i<40;i++){
        fields=await dpFields(list);
        if(fields.some((f:any)=>String(f.InternalName||'')===internalName))break;
        await dpSleep(350);
      }
      fields=await dpFields(list);
      if(!fields.some((f:any)=>String(f.InternalName||'')===internalName)){
        const diag=fields.map((f:any)=>`${String(f.Title||'')} [${String(f.InternalName||'')}]`).slice(-30).join(', ');
        throw new Error(`Feld ${displayTitle} konnte in ${list} nicht mit internem Namen ${internalName} erzeugt werden. Vorhanden: ${diag}`);
      }
      if(displayTitle!==internalName){
        await dpPost(
          `${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(list)}')/fields/getbyinternalnameortitle('${dpEsc(internalName)}')`,
          {Title:displayTitle},
          {'IF-MATCH':'*','X-HTTP-Method':'MERGE'}
        );
      }
      for(let i=0;i<20;i++){
        fields=await dpFields(list);
        const f=fields.find((x:any)=>String(x.InternalName||'')===internalName);
        if(f && dpFieldKey(String(f.Title||''))===dpFieldKey(displayTitle))return;
        await dpSleep(300);
      }
      throw new Error(`Feld ${internalName} wurde erzeugt, aber die sichtbare Bezeichnung ${displayTitle} konnte nicht gesetzt werden.`);
    };
    const dpEnsureList = async (title: string, schema:any): Promise<any> => {
      if(!(await dpListExists(title))){
        await dpPost(`${dpWebUrl()}/_api/web/lists`,{
          Title:title,BaseTemplate:100,Description:'DispoPilot isolierter Test-/Snapshot-Datenbestand'
        });
        await dpWaitList(title);
      }
      await dpEnsureFieldExact(title,schema.typTitle,schema.typInternal,schema.typType);
      await dpEnsureFieldExact(title,schema.dataTitle,schema.dataInternal,schema.dataType);
      const actual=await dpDiscoverSchema(title);
      if(actual.typInternal!==schema.typInternal || actual.dataInternal!==schema.dataInternal){
        throw new Error(`Feldschema in ${title} stimmt nicht: Typ ${actual.typInternal}, Daten ${actual.dataInternal}; erwartet ${schema.typInternal}, ${schema.dataInternal}`);
      }
      return actual;
    };
    const dpRecreateList = async (title: string, schema:any): Promise<any> => {
      if(await dpListExists(title)){
        await dpDelete(`${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(title)}')`);
        await dpWaitListGone(title);
      }
      return dpEnsureList(title,schema);
    };
    const dpItems = async (title: string, schema:any): Promise<any[]> => {
      const select=`Id,Title,${schema.typInternal},${schema.dataInternal}`;
      const j=await dpGet(`${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(title)}')/items?$select=${select}&$top=5000`);
      const rows=Array.isArray(j.value)?j.value:[];
      return rows.map((r:any)=>({
        Id:r.Id,
        Title:String(r.Title||''),
        DP_Typ:String(r[schema.typInternal]||''),
        DP_Daten:String(r[schema.dataInternal]||'')
      }));
    };
    const dpPostRow = async (title:string,schema:any,row:any):Promise<void> => {
      const body:any={Title:String(row.Title||'')};
      body[schema.typInternal]=String(row.DP_Typ||'');
      body[schema.dataInternal]=String(row.DP_Daten||'');
      await dpPost(`${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(title)}')/items`,body);
    };
    const dpPool = async <T>(rows: T[], concurrency: number, fn: (row:T,index:number)=>Promise<void>): Promise<void> => {
      let cursor=0;
      const worker=async():Promise<void>=>{
        while(true){
          const i=cursor++;
          if(i>=rows.length)return;
          await fn(rows[i],i);
        }
      };
      const count=Math.max(1,Math.min(Number(concurrency)||1,rows.length||1));
      await Promise.all(Array.from({length:count},()=>worker()));
    };
    const dpCopyRows = async (rows:any[],dst:string,schema:any,onDone?:()=>void):Promise<number> => {
      await dpPool(rows,4,async(row:any)=>{
        await dpPostRow(dst,schema,row);
        try{if(onDone)onDone()}catch(_){}
      });
      return rows.length;
    };
    const dpWriteReady = async (schema:any,snapshotCount:number,testCount:number):Promise<void> => {
      await dpPostRow('DP_Data_SNAPSHOT',schema,{
        Title:'DP|testReady',
        DP_Typ:'testReady',
        DP_Daten:JSON.stringify({
          ready:true,snapshotCount,testCount,preparedAt:new Date().toISOString(),
          typInternal:schema.typInternal,dataInternal:schema.dataInternal
        })
      });
    };
    const dpReadyInfo = async (schema:any):Promise<any|null> => {
      if(!(await dpListExists('DP_Data_SNAPSHOT')))return null;
      const rows=await dpItems('DP_Data_SNAPSHOT',schema);
      const marker=rows.find((r:any)=>String(r.DP_Typ||'')==='testReady');
      if(!marker)return null;
      try{return JSON.parse(String(marker.DP_Daten||'{}'))}catch(_){return null}
    };
    const dpTestReadyPrefix='DispoLuxTestReady:';
    const dpSetTestReadyInfo = async (title:string,info:any):Promise<void> => {
      const payload={
        ready:true,
        testCount:Number(info?.testCount||0),
        preparedAt:String(info?.preparedAt||new Date().toISOString())
      };
      await dpPost(
        `${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(title)}')`,
        {Description:dpTestReadyPrefix+JSON.stringify(payload)},
        {'IF-MATCH':'*','X-HTTP-Method':'MERGE'}
      );
    };
    const dpTestReadyInfo = async (title:string):Promise<any|null> => {
      if(!(await dpListExists(title)))return null;
      const j=await dpGet(`${dpWebUrl()}/_api/web/lists/getbytitle('${dpEsc(title)}')?$select=Description,ItemCount`);
      const d=String(j.Description||'');
      if(!d.startsWith(dpTestReadyPrefix))return null;
      try{
        const x=JSON.parse(d.slice(dpTestReadyPrefix.length));
        return {...x,itemCount:Number(j.ItemCount||0)};
      }catch(_){return null}
    };
    const dpBridgeProgressBox = (): HTMLElement => {
      let el=document.getElementById('dpV7BridgeProgress') as HTMLElement|null;
      if(!el){
        el=document.createElement('div');
        el.id='dpV7BridgeProgress';
        el.style.cssText='position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483000;background:#fff;border:2px solid #176b3a;border-radius:12px;padding:10px 16px;font:600 14px Arial,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.25);display:none;max-width:80vw;text-align:center';
        document.body.appendChild(el);
      }
      return el;
    };
    const dpBridgeProgressShow = (text:string):void => {
      try{const el=dpBridgeProgressBox();el.textContent=text;el.style.display='block';}catch(_){}
    };
    const dpBridgeProgressHide = ():void => {
      try{const el=document.getElementById('dpV7BridgeProgress') as HTMLElement|null;if(el)el.style.display='none';}catch(_){}
    };
    window.addEventListener('message', async (event: MessageEvent) => {
      const data: any = event.data;
      if(!data || data.type!=='DISPOPILOT_TEST_CONTROL')return;
      const frame=dpTestDom.querySelector('iframe') as HTMLIFrameElement|null;
      if(!frame || !frame.contentWindow)return;
      const source:any=frame.contentWindow;
      const reply=(ok:boolean,extra?:any,error?:string):void=>{
        try{source.postMessage({
          type:'DISPOPILOT_TEST_CONTROL_RESULT',
          requestId:String(data.requestId||''),ok,...(extra||{}),error:error||''
        },'*')}catch(_){}
        setTimeout(dpBridgeProgressHide,1200);
      };
      let currentStage='Start';
      const progress=(stage:string,current:number=0,total:number=0):void=>{
        currentStage=stage;
        const label=total>0?`${stage} ${current}/${total}`:`${stage} …`;
        dpBridgeProgressShow(label);
        try{source.postMessage({
          type:'DISPOPILOT_TEST_CONTROL_PROGRESS',
          requestId:String(data.requestId||''),stage,current,total
        },'*')}catch(_){}
      };
      try{
        const action=String(data.action||'');
        const prod='DP_Data', test='DP_Data_TEST', snap='DP_Data_SNAPSHOT';
        progress('Datenstruktur prüfen');
        const schema=await dpDiscoverSchema(prod);
        if(action==='prepare'){
          progress(`Echtbestand lesen (${schema.typInternal} / ${schema.dataInternal})`);
          const all=await dpItems(prod,schema);
          const snapshotRows=all.filter((r:any)=>String(r.DP_Typ||'')!=='testReady');
          const testRows=snapshotRows.filter((r:any)=>String(r.DP_Typ||'')!=='mailQueue');
          progress('Snapshot neu anlegen');
          await dpRecreateList(snap,schema);
          progress('Testbestand neu anlegen');
          await dpRecreateList(test,schema);
          let snapDone=0;
          progress('Snapshot kopieren',0,snapshotRows.length);
          await dpCopyRows(snapshotRows,snap,schema,()=>{
            snapDone++;
            if(snapDone===snapshotRows.length||snapDone%5===0)progress('Snapshot kopieren',snapDone,snapshotRows.length);
          });
          let testDone=0;
          progress('Testbestand kopieren',0,testRows.length);
          await dpCopyRows(testRows,test,schema,()=>{
            testDone++;
            if(testDone===testRows.length||testDone%5===0)progress('Testbestand kopieren',testDone,testRows.length);
          });
          progress('Abschluss speichern');
          await dpWriteReady(schema,snapshotRows.length,testRows.length);
          await dpSetTestReadyInfo(test,{testCount:testRows.length,preparedAt:new Date().toISOString()});
          reply(true,{
            ready:true,snapshotCount:snapshotRows.length,testCount:testRows.length,
            typInternal:schema.typInternal,dataInternal:schema.dataInternal
          });
          return;
        }
        if(action==='reset'){
          await dpEnsureList(snap,schema);
          const ready=await dpReadyInfo(schema);
          if(!ready?.ready)throw new Error('Kein vollständig vorbereiteter Snapshot vorhanden. Bitte zuerst vorbereiten.');
          progress('Snapshot lesen');
          const rows=(await dpItems(snap,schema))
            .filter((r:any)=>String(r.DP_Typ||'')!=='testReady'&&String(r.DP_Typ||'')!=='mailQueue');
          progress('Testbestand neu anlegen');
          await dpRecreateList(test,schema);
          let done=0;
          progress('Testdaten zurücksetzen',0,rows.length);
          await dpCopyRows(rows,test,schema,()=>{
            done++;
            if(done===rows.length||done%5===0)progress('Testdaten zurücksetzen',done,rows.length);
          });
          await dpSetTestReadyInfo(test,{testCount:rows.length,preparedAt:new Date().toISOString()});
          reply(true,{ready:true,snapshotCount:Number(ready.snapshotCount||0),testCount:rows.length});
          return;
        }
        if(action==='status'){
          const ready=await dpTestReadyInfo(test);
          reply(true,{
            ready:!!ready?.ready,
            snapshotCount:0,
            testCount:Number(ready?.itemCount||ready?.testCount||0),
            preparedAt:String(ready?.preparedAt||'')
          });
          return;
        }
        throw new Error('Unbekannte Testbetrieb-Aktion.');
      }catch(err:any){
        const msg=String((err&&err.message)||err||'Testdaten-Fehler').slice(0,1100);
        reply(false,undefined,currentStage+': '+msg);
      }
    });
  }
/* eslint-enable */
// DP_L2_MAILQUEUE_BRIDGE_BEGIN
  const dpQueueWindow: any = window as any;
  if (!dpQueueWindow.__DISPOPILOT_MAILQUEUE_BRIDGE_V2) {
    dpQueueWindow.__DISPOPILOT_MAILQUEUE_BRIDGE_V2 = true;
    const dpQueueContext: any = this.context as any;
    const dpQueueDom: HTMLElement = this.domElement;
    window.addEventListener('message', async (event: MessageEvent) => {
      const data: any = event.data;
      if (!data || data.type !== 'DISPOPILOT_MAILQUEUE_CREATE') return;
      const frame = dpQueueDom.querySelector('iframe') as HTMLIFrameElement | null;
      if (!frame || event.source !== frame.contentWindow) return;
      const source: any = event.source;
      const reply = (ok: boolean, itemId?: number, error?: string): void => {
        try {
          if (source && source.postMessage) {
            source.postMessage({
              type: 'DISPOPILOT_MAILQUEUE_RESULT',
              requestId: String(data.requestId || ''),
              ok,
              itemId: itemId || null,
              error: error || ''
            }, '*');
          }
        } catch (_) {}
      };
      try {
        const payload: any = data.payload || {};
        const isTestMode: boolean = payload.testMode === true;
        const forcedTestEmail: string = String(payload.testEmail || '').trim();
        const requestedTo: string[] = (Array.isArray(payload.to) ? payload.to : [])
          .map((x: any) => String(x || '').trim())
          .filter((x: string) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))
          .slice(0, 10);
        const to: string[] = isTestMode
          ? (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(forcedTestEmail) ? [forcedTestEmail] : [])
          : requestedTo;
        const pdf64 = String(payload.attachmentBase64 || '');
        if (!to.length) throw new Error('Kein gültiger E-Mail-Empfänger.');
        if (!pdf64 || pdf64.length > 900000) throw new Error('PDF-Anhang fehlt oder ist zu groß.');
        payload.to = to;
        payload.status = 'Pending';
        const id = `mail-${Date.now()}-${Math.floor(Math.random()*1000000)}`;
        const body = JSON.stringify({
          Title: `DP|mailQueue|${id}`,
          DP_Typ: 'mailQueue',
          DP_Daten: JSON.stringify(payload)
        });
        const webUrl = String(dpQueueContext.pageContext.web.absoluteUrl || '').replace(/\/$/, '');
        const queueList = isTestMode ? 'DP_Data_TEST' : 'DP_Data';
                  const url = `${webUrl}/_api/web/lists/getbytitle('${queueList}')/items`;
        const response = await dpQueueContext.spHttpClient.post(
          url,
          SPHttpClient.configurations.v1,
          {
            headers: {
              'Accept': 'application/json;odata=nometadata',
              'Content-Type': 'application/json;odata=nometadata'
            },
            body
          }
        );
        if (!response.ok) {
          const detail = await response.text();
          throw new Error(`SharePoint ${queueList} ${response.status}: ${detail.slice(0,400)}`);
        }
        const json: any = await response.json();
        reply(true, Number(json && (json.Id || json.ID) || 0));
      } catch (err: any) {
        const msg=String((err && err.message) || err || 'MailQueue konnte nicht angelegt werden.').slice(0,900);
        reply(false, undefined, msg);
      }
    });
  }
// DP_X14_SHAREPOINT_BRANDING_BEGIN
  const dpBrandWindow: any = window as any;
  const dpBrandIcon: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAQKklEQVR42r2aeZxU1ZXHv+fe96qq2RfRgKxd1ahoUNMmLiit0NUgmugkqSRmNItmcItLxmRGP2r4QJLJ4kyMJho1xohZTcuoYAh0sxuJiq0jmpalqsWNVna6m17qvXvP/FElASMECOb+9eot9/7OOb97tluwv5GZ2o/Rkz9b+pGz/NNGea0x2U9TWdv/UGaQ3RfpuucZM7kWgJqa4APH/u4a6clnS6Zu1fth2nPsW6tHZXtzRCYtgaTFBrfSf/Rz/N/SAswwsFw/GPQzDK/NdozO1kkY1uNZwYDRr1BxfBcd66L3+8Lsc6Lh24oE8m2cH4aLk2JNA+m6a2CmLwnxAYBnpqeq7hoJzUJcnER0BCb4Jq3txX2tuQ8LHGloXRQzaHSPBIlbUA3Bi0CWwaN+w7ZdOyEnh88SMww0C1VDx4iXuaAGIYEJK1H/n2xfsg6ONNCsB2iBegcIhcWPa1z8FMY8j6KAoDZTer7scFrBQL1DTQYIUAUTvKCueAGFhgW7nx84hQBQqAloWfS/6tyjGCsIVrD3k558ASyPD49nylmYGVNVe56I/RmCwVjURwsoLJpb3tT+73qbfTxThk0eLL2CDer9HYi8Ltbei/dONb6UwuKHoCYoCXOo4Osdo2svkSB4AGMC1egKVAcIdpYWO0fz+pOtu7EcnAVqLICpkE8i0geRByk03KdxdCVgRIKfM2bypw7dEmXwY7IfF2vvB7UaF69kfeO9RInZoIFJpD63J5ZD2FggmbpFks6+spe10nXXSNW5Kpm67YyaevKe7x/M3FRNO04ydZul6lwlU3v9nqyQzJRnJJN9qsxm2c/m2Rd9ZnqG1PQBPUPFPAszhHT2R4yqGUCh4cfq3N2YcACB+wWDz+h7AJTcm7bDT6vAF3+BSRyhPn6A/KIfcVS2N+m6/wGMercK5RQyU/uB6L7mNvtdpF9qLCaswLu3YKYXYbqEyXtLX5qbcMXVYhMn0r/X7TDTk8sZmGFKG68mKNEkZ6mpCUr3ZpjSOzM9if7fF5s4FdezjqR8A0D6yl0ieiXgUX0LGybwMnZ/ytlHapATqAfccCQBaGfJklrAJj4j6ew2zS+4UiuzN4pGT4i1l2lVdgP19d8GYPl7vMbyPS7qgUzdjSJcgzpU7C00L9gm6Sm3Y+wXcdG6coTqRixI17C9MR2QAOXhtW9Jbu1V1voK8Cdg7BWkpyiFhVdpuna+mOB8wXxLMlPEG3nc+HiCqo5F7GBQ8LwjIuu84VlUPiHCLAB1fiktjfVkptwJcg2qgCnx3jGgHGZT+4O4fwFMEKGqiOkPM4z6P/9aJJ6E6lgx4ZWk6/oq7leo1hliK8bMMl5vxdrQq6AKImDKPkRjFyGEeO+QQIHZkql7CDGX4CMHpsUafTAGQRiEqoLt+TsR8H0j8bs+N493AmZUmYbTEStAXIotegpel6F+retJ2rjDuLgrCOMOvC/GzlB0Popd3E4c7/JO0RB1DjEWH28gYRpQTi7HKY8YiTH/BjmDsSPxsUAx/x5MB2SB0q4vbHmJ9KB1IpyiNAvi7gEzDRMk8L5J4+KZBKnLDJqpHfd2XBH6oBgbImfci629dNO23omBAzv92SdsNu3dgSzbMEBjJ0bwisgIHBdrsn+1FHcuwQQTUB0E7n6oR8ieisYvUzhiTcmNij9IAXIW6iP1dTdIaOcxZlua/OLnyEzdichmbes5W/pX3Gwst/gudX0q4p4Hv/wSfaxaLKa7R/yNc6qKdy8ezc3T8jpmcHdyxK0TJY4DxCiqPhCCH1BsH64735wq/Uc8iXAEXR3PUllbiQmOUhd9sZQDfcYC7mDqAYFmT7puBM4HxvCGivZhYOZTYux5Wowm0Ttxi4i9AR+j1ppXNvZy15/1qvvls0PtDbM/7FK9iu4/L3w9nP/CYDegd+xPGNYR/nDpaGJvEFGPWAsKYk8l1Xc0WvyaSPhVbDgIJGHENym8woBxhu2P7TjYOFB+6kIJedy7+M94XhEjXxNXvBkrN4kJr0QdiLyE5/FUMg4ToQb5rb3MijVDEl94aLzdstm6uhM3qUewouVkRh02NKr6oiJL0Qix4eeR4DvqirNEzOWIX+u9e0qQR/G75BA2cXl07HgbBTHBfLH2LuAtxZwriYpLiIvrVPyXhlTo6bQsuDAV+i9ZI3EiULV9eghEpb3LOmvw+i72Enir6uYQF88m311n1FxAXFwlQcUFgvwL6l8TY38oEsxH8Wx44+1DEUABQ2tTp2J+izEBqh8FV0UQnqOu53Yt9B/H+sbZm1Y37qK6OtzVvPxXffv6TYqI8yUXamVPTqrHhpbYzWN946d57ch2WB67wsK5mm/4mLqeW7Hh6Ygeg9fTEJtSpB7yxTLV9SDjwLuRTx5D/TWod0iwWV1xBoF9MnXs1lxoJqW8NU27mib8JXVcv0uJlyVKC8neZhdVxRpRV6DI1yVT+3nN1/8uPL7uxJSPqiNvu7tVH1EfrxG130PdSNRZVOeWHQrvF4X3J4DAOGX4aRWIfhtUsEGIuu2IudQ6/Wl3sVfQHQNJF1P5zD0q0r2lPfgQ3v9N4iWCxwYkjJ/dnar4ulLskkzdqdEuc3VU7G0JFJsoOq/yPLgdGJMGFCOzGFr9NK3juvdVE+wrFzIw05GsvVpscgKuG7y+gsgSHMf0SUZ8dXJ+R09skvNeHBKu2zrwq87xRtLGRUSSIooRLWUGgHqx+IjIcYkhGmVEtztvjjpmSHt0/vh3iqHxPXetGNWvPQrfFiMvlcpXPUWC1AStGHQ1zLxtd/1wAHugVH+m60YI5pu44nyFT+iQtmrNN16bTLpVbe29g56iSdw2PZ+48KS3nRa979pRMeL3TR/SioRDiwFRHEho1YiUsylVIh9U+cgknDNHaae4XPXG4n9PzyfaOhKp9l29TDLh12i+8WYtnH6qqtaixUfFyK1U1o4sgzcH7oWUs1T8FbprS4584zyefrpLMnUPR85erDZ+5uEXjg7dZtzxQ3dZOq1eNqmlc97qI/XttkRPvz7dPVfWbPDDhkXh8xv6GysY79GUjTpPGbOt66qzXu+kM/Djh7WHPa3iHlk9NIGNGyInOclMbWRcfUDLosXqCxcpehlWzjiYZM4DhpaG31B5ziRSg88F5kg6+12Cis/47s6aRK+o+o0dA079+u+rdt6eW5/68H8t56RjOhK/XHFUtPbNPl0772tModj6lUOiuauGmYs/tjE6Yqj3m76zjIoUFsVeceabxROO3sUVDx0bbero1y+Z6ni4J7ZrJEw+JT3D71Sar4BRWVTbyC9aWFa2P4CifoaBmcqYqR8Wo/dp0J7F9z1JxK7AFVdrYdFJDJs8yPQyc32UOmP8sC065fhNUY8zLt/aW19+p2/qc6dsjF58vb8uXDM4RI09/8TWtvFHdySKsYQG7RJBERJ/fOmo5OqNQzCJ7uXe+QtoWdQm6doXsIkTVXuyDB70lGxpW2adXhO/2vDs7ubXgeRCYvTHCgtZu7Jd0tlvEYSqyB+pqbEsX7zVD63OBv0GX7X6rQGfW/3qoBOwpgLiLgJ/9w/mHfMFAt/HJGNRifWJF4f3e2KVbKfHPkDSXYo1KWLfRVL/HFR0/S529l5aGnogZ5XtDSIyXpz5pj5dP5H0lAXOyJ3AaQfSVimZaeyk8eKDJiU6FpMcJN4/AyKq7gIKi+ZCLgH1RYAZMwjumX/OMW3t5qKiszcHuDTG/NARXOBcBBgCwwpjdcPAZNf3t3ZV/CXE3zqgr69/a9XS9SJlWlRXhzQ1RWSynxax9ajzKlTjTSSiLymumvziF95LJfOezrABMLE9G/DklxZw7vMYK6jbgYiSnvIVxr0rfE0wc+YM/86qpX/pisM5HlkSO3dcMdaJzsUrEdumnksjx2XFyJ73dntyZOzN8k4N5258bulakZyUaueyIjN1X0YDi3NtmMDg+SyFLetAxKhM2BPj+wtw5JFajpx91cvl5SA0Ee89qkaUBwV/G1vXhuUa11OzzAAiorPwrtOb5M9Btml3e616raal4RfEPW+ivk0kuB+vbeL1+3/NhM8uafOdMBDV20Tin4IH772I1EBTpKqXg++3F8b9tkFG1QzgteU7yEwdIhqvxZiBKKAejHGqXEi+4QnGjUvQ3FwkU/cDsYlv4GMQi/quHPklj5TnSvHa8m6qaj8pJjkH70AC1PXcQaHxejJTk+QX9JDJflyQR1FvEVNC5n2rSnAs+QVtjDxzIK//afvBtBYNlbVpMbIGpIDzeayZAoiiTXS3T+TNp7uonHytBKk71BcfB10omPNQvx0xfVH5EKIekY1414WYvopfiJpzxYYf17h4HS2NdzL0/F707nlSkJNL6YI+ARyH19EaMZo3FrXuK5mT/WSpnvRZI0QqXlV1tThGSiI5m7iniE0kVP1PMHqXKM8ocgXrF/4WgGOnDJXYP4JJnIEvt0xNCL74pLo4x6tL3inz/V9F5CeKOwNvrhNjLsdFRYJkQqP4YgwbRfQPWuw6uqz5940D+0unQXp3q/rHKCxeRhi8io+01FWIVHBXiZeV6vUR1i/8LTU1AdXVIWsWtmq+cYL66DLwnaBd6orTNd8wkVeXvEN1dUhNTUC+4dfqdY5gnxL8dHy8e26MtFBoWKrqHyZI+b0wHZQAib47CbgWEIrdq1Bdi1hQYrxGWDsQdesgZ+noEJqaYsblEozLJcg3PIBnDqrzKTT8DKaHjMslaGqK6egQyFlU1yF2INCNEiEWVV6isOU5QIiTNzFwe+f+BNh/13dzs2NrSzvkLDvnRwzKGAmS01T9o4hdLxIcJ95vY/u8elrPLNXRm5sdm5sdVdmTBLkFqGRQ1WK2//4tNjeXssnW6cDdnoGV14sJjlN0DiKviU0ei8Y3s+1Pz0FNwM5FbbS2+gM6jTygd4bnUpLcuU6FP6BynxhpQrVDvTuHlkXPMaYui7jTMPYEUaYiuqHUEZG0qv4RdS+CWUlL4xIqa08REywDkurdyVhzk3j/ES1sGw/nO5ip+9P8gdXEf52gVKS8Wd+lnktFpDeFhc+rj2/GJvqImPsYUtOHIG4WY68TOEvVnKf5xo9ooeEjKn6aCGeK2OsIdQ3DT6sQsfdgwt5K/A1aGl8WQA1fgqboPese1lGyRromw/BcRem69gYZO00lPWVh+TzhDpOe/O+luqjcmQZM5aT/kEz2TgCpmjJPxk5TqrLX7m61j8yOOQhWHBSF3v/oac+j0crsBAnCe8E36fauqxlgx+GDbRROb4FmoXJ7JcRHEhZXi+v3E4x8VF33VygsXUkuZ6nfXWnJwWpd/gFL6F5HRdQEkun1XfXxZsQ8iegs8g3Z0knM1PngvofjNLHBUF2//kbI97ynTJRDoYwcHmbtASR9TjXOpiURPKyxuwjxXWITj2kcXwSap2XRc3/zzT/M6cO2P3Ll89wZhvTKhSLmDERjVX2Z/ICJpWc5C/X+g9igh/efJlXnHS2Z7EbJ1G2janLlP/8fL/+QDCWgJl17iUnXTd/z3uEe/w8bOM+sNr28xQAAAABJRU5ErkJggg==';
  const dpBrandReplace = (value: string): string => String(value || '').replace(/DispoPilot/gi,'DispoLux');
  const dpBrandApply = (): void => {
    try {
      if (document.title) document.title = dpBrandReplace(document.title);
      const oldImgs = Array.from(document.querySelectorAll('img')) as HTMLImageElement[];
      oldImgs.forEach((img: HTMLImageElement) => {
        const label = String(img.alt || '') + ' ' + String(img.title || '');
        if (/DispoPilot/i.test(label)) {
          img.src = dpBrandIcon;
          img.alt = dpBrandReplace(img.alt || 'DispoLux');
          img.title = dpBrandReplace(img.title || '');
          img.style.objectFit = 'contain';
        }
      });
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const nodes: Node[] = [];
      let node: Node | null;
      while ((node = walker.nextNode())) {
        const parent = (node as any).parentElement as HTMLElement | null;
        if (!parent || /^(SCRIPT|STYLE|TEXTAREA)$/i.test(parent.tagName)) continue;
        if (/DispoPilot/i.test(String(node.nodeValue || ''))) nodes.push(node);
      }
      nodes.forEach((n: Node) => { n.nodeValue = dpBrandReplace(String(n.nodeValue || '')); });
      Array.from(document.querySelectorAll('[title],[aria-label]')).forEach((el: Element) => {
        const title = el.getAttribute('title');
        const aria = el.getAttribute('aria-label');
        if (title && /DispoPilot/i.test(title)) el.setAttribute('title',dpBrandReplace(title));
        if (aria && /DispoPilot/i.test(aria)) el.setAttribute('aria-label',dpBrandReplace(aria));
      });
      let fav = document.querySelector('link[data-dpx14-shell-icon="1"]') as HTMLLinkElement | null;
      if (!fav) {
        fav = document.createElement('link');
        fav.rel = 'icon';
        fav.type = 'image/png';
        fav.setAttribute('data-dpx14-shell-icon','1');
        document.head.appendChild(fav);
      }
      fav.href = dpBrandIcon;
    } catch (_) {}
  };
  dpBrandApply();
  if (!dpBrandWindow.__DISPOLUX_SHELL_BRAND_OBSERVER) {
    dpBrandWindow.__DISPOLUX_SHELL_BRAND_OBSERVER = new MutationObserver(() => dpBrandApply());
    dpBrandWindow.__DISPOLUX_SHELL_BRAND_OBSERVER.observe(document.body, {childList:true,subtree:true});
  }
  // DP_X14_SHAREPOINT_BRANDING_END
this.domElement.innerHTML = '<div class="dp-spfx-host" style="width:100%;min-height:760px"></div>';
    const host = this.domElement.querySelector('.dp-spfx-host') as HTMLDivElement;

  /* DP_DLB_028D_1_12_1_0_DATENSICHERUNG_DATENINTEGRITAET_BEGIN */
  const dp28dWindow: any = window as any;
  if (!dp28dWindow.__DISPOLUX_DATA_GUARD_028D) {
    Object.defineProperty(dp28dWindow, '__DISPOLUX_DATA_GUARD_028D', { value: true, writable: true, configurable: true });
    let dp28dQueue: Promise<void> = Promise.resolve();
    const dp28dContext: any = this.context as any;
    const dp28dList = 'DP_Data';
    const dp28dBackupPrefix = 'DPB|';
    const dp28dBackupIntervalMs = 2 * 60 * 60 * 1000;
    const dp28dRetentionMs = 54 * 60 * 60 * 1000;
    const dp28dCheckIntervalMs = 10 * 60 * 1000;
    const dp28dWebUrl = (): string => String(dp28dContext.pageContext.web.absoluteUrl || '').replace(/\/$/, '');
    const dp28dEsc = (v: string): string => String(v || '').replace(/'/g, "''");
    const dp28dHeaders: any = {
      'Accept': 'application/json;odata=nometadata',
      'Content-Type': 'application/json;odata=nometadata'
    };

    const dp28dWarn = (message: string): void => {
      try {
        let box = host.querySelector('#dp28dDataWarning') as HTMLDivElement | null;
        if (!box) {
          box = document.createElement('div');
          box.id = 'dp28dDataWarning';
          box.style.cssText = 'display:none;margin:0 0 8px 0;padding:9px 12px;border:2px solid #b91c1c;border-radius:9px;background:#fef2f2;color:#7f1d1d;font:700 13px Arial,sans-serif';
          host.insertBefore(box, host.firstChild);
        }
        box.textContent = message;
        box.style.display = message ? 'block' : 'none';
      } catch (_) {}
    };

    const dp28dGet = async (url: string): Promise<any> => {
      const response: any = await dp28dContext.spHttpClient.get(
        url,
        SPHttpClient.configurations.v1,
        { headers: { 'Accept': 'application/json;odata=nometadata', 'Cache-Control': 'no-cache' } }
      );
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`GET ${response.status}: ${detail.slice(0,500)}`);
      }
      return response.json();
    };

    const dp28dPost = async (url: string, body?: any, extra?: any): Promise<any> => {
      const headers: any = { ...dp28dHeaders, ...(extra || {}) };
      const options: any = { headers };
      if (body !== undefined) options.body = typeof body === 'string' ? body : JSON.stringify(body);
      const response: any = await dp28dContext.spHttpClient.post(
        url,
        SPHttpClient.configurations.v1,
        options
      );
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`POST ${response.status}: ${detail.slice(0,700)}`);
      }
      const text = await response.text();
      if (!text) return {};
      try { return JSON.parse(text); } catch (_) { return {}; }
    };

    const dp28dDelete = async (id: number): Promise<void> => {
      await dp28dPost(
        `${dp28dWebUrl()}/_api/web/lists/getbytitle('${dp28dEsc(dp28dList)}')/items(${id})`,
        undefined,
        { 'IF-MATCH': '*', 'X-HTTP-Method': 'DELETE' }
      );
    };

    const dp28dFields = async (): Promise<any> => {
      const data = await dp28dGet(`${dp28dWebUrl()}/_api/web/lists/getbytitle('${dp28dEsc(dp28dList)}')/fields?$select=Title,InternalName,TypeAsString&$top=5000`);
      const fields: any[] = Array.isArray(data.value) ? data.value : [];
      const norm = (v: any): string => String(v || '').replace(/_x005f_/gi,'_').replace(/\s+/g,'_').toLowerCase();
      const find = (name: string): any => fields.find(x => norm(x.Title) === norm(name)) || fields.find(x => norm(x.InternalName) === norm(name));
      const typ = find('DP_Typ') || find('Wert');
      const daten = find('DP_Daten');
      if (!typ || !daten) throw new Error('DP_Typ oder DP_Daten in DP_Data nicht gefunden.');
      return { typ: String(typ.InternalName), daten: String(daten.InternalName) };
    };

    const dp28dLoadRows = async (fields: any): Promise<any[]> => {
      let url = `${dp28dWebUrl()}/_api/web/lists/getbytitle('${dp28dEsc(dp28dList)}')/items?$select=Id,Title,${encodeURIComponent(fields.typ)},${encodeURIComponent(fields.daten)}&$top=5000`;
      const rows: any[] = [];
      while (url) {
        const data = await dp28dGet(url);
        const part: any[] = Array.isArray(data.value) ? data.value : [];
        for (const x of part) rows.push({
          Id: Number(x.Id || x.ID || 0),
          Title: String(x.Title || ''),
          DP_Typ: String(x[fields.typ] || ''),
          DP_Daten: String(x[fields.daten] || '')
        });
        url = String(data['@odata.nextLink'] || data?.d?.__next || '');
      }
      return rows;
    };

    const dp28dCreateRow = async (fields: any, title: string, typ: string, daten: string): Promise<void> => {
      const body: any = { Title: title };
      body[fields.typ] = typ;
      body[fields.daten] = daten;
      await dp28dPost(`${dp28dWebUrl()}/_api/web/lists/getbytitle('${dp28dEsc(dp28dList)}')/items`, body);
    };

    const dp28dStamp = (d: Date): string => d.toISOString().replace(/[-:.]/g,'');

    const dp28dBackup = async (fields: any, rows: any[], force: boolean = false): Promise<void> => {
      const now = Date.now();
      const backupRows = rows.filter(x => String(x.Title || '').startsWith(dp28dBackupPrefix));
      const metas = backupRows.filter(x => String(x.DP_Typ || '') === 'backupMeta');
      let latest = 0;
      for (const meta of metas) {
        try {
          const parsed = JSON.parse(String(meta.DP_Daten || '{}'));
          if (parsed && parsed.complete === true) latest = Math.max(latest, Date.parse(String(parsed.capturedAt || '')) || 0);
        } catch (_) {}
      }
      if (!force && latest > 0 && now - latest < dp28dBackupIntervalMs) return;

      const live = rows.filter(x => String(x.Title || '').startsWith('DP|'));
      const stamp = dp28dStamp(new Date(now));
      for (let i = 0; i < live.length; i++) {
        const row = live[i];
        const backupTitle = `${dp28dBackupPrefix}${stamp}|${row.Id}|${row.Title}`;
        if (backupTitle.length > 255) throw new Error('Backup-Titel zu lang: ' + row.Title);
        await dp28dCreateRow(fields, backupTitle, `backup|${row.DP_Typ}`, row.DP_Daten);
      }
      await dp28dCreateRow(
        fields,
        `${dp28dBackupPrefix}${stamp}|__meta`,
        'backupMeta',
        JSON.stringify({
          complete: true,
          capturedAt: new Date(now).toISOString(),
          sourceList: dp28dList,
          recordCount: live.length,
          intervalHours: 2,
          retentionHours: 54,
          build: 'DLB-028D-1.12.1.0'
        })
      );

      // Erst NACH erfolgreichem neuen Snapshot alte vollständige Sicherungen entfernen.
      const staleStamps = new Set<string>();
      for (const meta of metas) {
        try {
          const parsed = JSON.parse(String(meta.DP_Daten || '{}'));
          const ts = Date.parse(String(parsed.capturedAt || '')) || 0;
          if (parsed && parsed.complete === true && ts > 0 && now - ts >= dp28dRetentionMs) {
            const parts = String(meta.Title || '').split('|');
            if (parts.length >= 3) staleStamps.add(parts[1]);
          }
        } catch (_) {}
      }
      if (staleStamps.size) {
        const stale = backupRows.filter(x => {
          const parts = String(x.Title || '').split('|');
          return parts.length >= 3 && staleStamps.has(parts[1]);
        });
        for (let i = 0; i < stale.length; i++) {
          await dp28dDelete(stale[i].Id);
        }
      }
      console.info(`DispoLux Backup ${stamp}: ${live.length} Datensätze gesichert.`);
    };

    const dp28dIntegrity = async (fields: any, rows: any[]): Promise<void> => {
      const live = rows.filter(x => String(x.Title || '').startsWith('DP|'));
      const byTitle = new Map<string, number>();
      live.forEach(x => byTitle.set(x.Title, (byTitle.get(x.Title) || 0) + 1));
      const duplicateTitles = Array.from(byTitle.entries()).filter(x => x[1] > 1).map(x => x[0]);

      const singletonTypes = ['meta','drivers','vehicles','customers','sites','documents','archiveOrders','archiveTimeEntries','bins','binMovements','materials','settings'];
      const singletonProblems: string[] = [];
      for (const typ of singletonTypes) {
        const typed = live.filter(x => String(x.DP_Typ || '') === typ);
        const expected = `DP|${typ}`;
        if (typed.length > 1 || typed.some(x => x.Title !== expected)) singletonProblems.push(`${typ}(${typed.length})`);
      }

      if (duplicateTitles.length || singletonProblems.length) {
        const bits: string[] = [];
        if (duplicateTitles.length) bits.push('doppelte Schlüssel: ' + duplicateTitles.slice(0,6).join(', '));
        if (singletonProblems.length) bits.push('Singleton-Konflikte: ' + singletonProblems.join(', '));
        dp28dWarn('DATENWARNUNG – ' + bits.join(' · ') + '. Bitte keine Datenbereinigung automatisch durchführen.');
        return;
      }
      dp28dWarn('');

      // Datenbankseitiger Schutz: Title wird eindeutig. Läuft als Admin einmal erfolgreich
      // und schützt danach auch Schreibvorgänge anderer Benutzer vor neuen Dubletten.
      try {
        await dp28dPost(
          `${dp28dWebUrl()}/_api/web/lists/getbytitle('${dp28dEsc(dp28dList)}')/fields/getbyinternalnameortitle('Title')`,
          { Indexed: true, EnforceUniqueValues: true },
          { 'IF-MATCH': '*', 'X-HTTP-Method': 'MERGE' }
        );
      } catch (e) {
        // Fahrer/Gäste haben i.d.R. keine Listenverwaltungsrechte. Der einmalige Admin-Lauf genügt.
        console.warn('DispoLux Titelschutz konnte in diesem Benutzerkontext nicht gesetzt werden.', e);
      }
    };

    const dp28dRun = (force: boolean = false): Promise<void> => {
      dp28dQueue = dp28dQueue.then(async (): Promise<void> => {
        try {
          const fields = await dp28dFields();
          const rows = await dp28dLoadRows(fields);
          // Sicherung immer vor Integritäts-/Schemaänderungen.
          /* DP_DLB_030AE_1_12_1_24_DPB_AUS_DP_DATA_ENTFERNT_BEGIN */
                    // Produktive DP_Data bleibt frei von DPB|-Sicherungsdatensätzen.
                    // Die 028D-Integritätsprüfung bleibt aktiv; nur der alte Backup-Schreibvorgang entfällt.
                    /* DP_DLB_030AE_1_12_1_24_DPB_AUS_DP_DATA_ENTFERNT_END */
          await dp28dIntegrity(fields, rows);
        } catch (e) {
          console.error('DispoLux Datensicherung/Datenintegrität', e);
          dp28dWarn('DATENSICHERUNG FEHLGESCHLAGEN – ' + String((e as any)?.message || e || 'unbekannter Fehler'));
        }
      });
      return dp28dQueue;
    };

    dp28dWindow.dpDispoLuxBackupNow = (): Promise<void> => dp28dRun(true);
    dp28dRun(false).catch((e: unknown) => console.error('DispoLux Datensicherung Start', e));
    Object.defineProperty(dp28dWindow, '__DISPOLUX_DATA_GUARD_028D_TIMER', { value: window.setInterval(() => { dp28dRun(false).catch((e: unknown) => console.error('DispoLux Datensicherung Intervall', e)); }, dp28dCheckIntervalMs), writable: true, configurable: true });
  }
  /* DP_DLB_028D_1_12_1_0_DATENSICHERUNG_DATENINTEGRITAET_END */

  /* DP_DLB_030AH_1_12_1_27_BACKUP_30MIN_FILES_BEGIN */
  const dp30ahWindow: any = window as any;
  if (!dp30ahWindow.__DISPOLUX_FILE_BACKUP_030AH) {
    Object.defineProperty(dp30ahWindow, '__DISPOLUX_FILE_BACKUP_030AH', { value: true, writable: true, configurable: true });
    const dp30ahContext: any = this.context as any;
    const dp30ahDataList = 'DP_Data';
    const dp30ahLibrary = 'DispoLux_Backup';
    const dp30ahIntervalMs = 30 * 60 * 1000;
    const dp30ahRetentionMs = 54 * 60 * 60 * 1000;
    const dp30ahOpenedAt = Date.now();
    let dp30ahQueue: Promise<void> = Promise.resolve();
    let dp30ahLastSuccess = 0;
    let dp30ahLastCloseKick = 0;

    const dp30ahWebUrl = (): string => String(dp30ahContext.pageContext.web.absoluteUrl || '').replace(/\/$/, '');
    const dp30ahEsc = (v: string): string => String(v || '').replace(/'/g, "''");
    const dp30ahListApi = (title: string): string => `${dp30ahWebUrl()}/_api/web/lists/getbytitle('${dp30ahEsc(title)}')`;

    const dp30ahWarn = (message: string): void => {
      try {
        let box = host.querySelector('#dp30ahBackupWarning') as HTMLDivElement | null;
        if (!box) {
          box = document.createElement('div');
          box.id = 'dp30ahBackupWarning';
          box.style.cssText = 'display:none;margin:0 0 8px 0;padding:9px 12px;border:2px solid #b91c1c;border-radius:9px;background:#fef2f2;color:#7f1d1d;font:700 13px Arial,sans-serif';
          host.insertBefore(box, host.firstChild);
        }
        box.textContent = message;
        box.style.display = message ? 'block' : 'none';
      } catch (_) {}
    };

    const dp30ahGetResponse = async (url: string): Promise<any> => dp30ahContext.spHttpClient.get(
      url,
      SPHttpClient.configurations.v1,
      { headers: { 'Accept': 'application/json;odata=nometadata', 'Cache-Control': 'no-cache, no-store' } }
    );

    const dp30ahGet = async (url: string): Promise<any> => {
      const response: any = await dp30ahGetResponse(url);
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`GET ${response.status}: ${detail.slice(0,700)}`);
      }
      return response.json();
    };

    const dp30ahPost = async (url: string, body?: any, extraHeaders?: any): Promise<any> => {
      const headers: any = {
        'Accept': 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
        ...(extraHeaders || {})
      };
      const options: any = { headers };
      if (body !== undefined) options.body = typeof body === 'string' ? body : JSON.stringify(body);
      const response: any = await dp30ahContext.spHttpClient.post(url, SPHttpClient.configurations.v1, options);
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`POST ${response.status}: ${detail.slice(0,900)}`);
      }
      const txt = await response.text();
      if (!txt) return {};
      try { return JSON.parse(txt); } catch (_) { return {}; }
    };

    const dp30ahEnsureLibrary = async (): Promise<void> => {
      const check: any = await dp30ahGetResponse(`${dp30ahListApi(dp30ahLibrary)}?$select=Id,Title,BaseTemplate,EnableVersioning`);
      if (check.ok) {
        try {
          await dp30ahPost(dp30ahListApi(dp30ahLibrary), { EnableVersioning: false }, { 'X-HTTP-Method': 'MERGE', 'IF-MATCH': '*' });
        } catch (e) {
          console.warn('030AH: Versionsverwaltung der Backup-Bibliothek konnte nicht deaktiviert werden.', e);
        }
        return;
      }
      if (Number(check.status) !== 404) {
        const detail = await check.text();
        throw new Error(`Backup-Bibliothek prüfen ${check.status}: ${detail.slice(0,700)}`);
      }
      await dp30ahPost(`${dp30ahWebUrl()}/_api/web/lists`, {
        Title: dp30ahLibrary,
        Description: 'Automatische DispoLux-Datensicherungen. Eine JSON-Datei je 30-Minuten-Zeitfenster.',
        BaseTemplate: 101,
        OnQuickLaunch: false,
        EnableVersioning: false
      });
    };

    const dp30ahFields = async (): Promise<any> => {
      const data = await dp30ahGet(`${dp30ahListApi(dp30ahDataList)}/fields?$select=Title,InternalName,TypeAsString&$top=5000`);
      const fields: any[] = Array.isArray(data.value) ? data.value : [];
      const norm = (v: any): string => String(v || '').replace(/_x005f_/gi, '_').replace(/\s+/g, '_').toLowerCase();
      const find = (name: string): any => fields.find(x => norm(x.Title) === norm(name)) || fields.find(x => norm(x.InternalName) === norm(name));
      const typ = find('DP_Typ') || find('Wert');
      const daten = find('DP_Daten');
      if (!typ || !daten) throw new Error('DP_Typ oder DP_Daten in DP_Data nicht gefunden.');
      return { typ: String(typ.InternalName), daten: String(daten.InternalName) };
    };

    const dp30ahLoadLiveRows = async (): Promise<any[]> => {
      const f = await dp30ahFields();
      const filter = encodeURIComponent("startswith(Title,'DP|')");
      let url = `${dp30ahListApi(dp30ahDataList)}/items?$select=Id,Title,${encodeURIComponent(f.typ)},${encodeURIComponent(f.daten)}&$filter=${filter}&$top=5000`;
      const rows: any[] = [];
      while (url) {
        const data = await dp30ahGet(url);
        const part: any[] = Array.isArray(data.value) ? data.value : (Array.isArray(data?.d?.results) ? data.d.results : []);
        for (const x of part) {
          const title = String(x.Title || '');
          if (!title.startsWith('DP|')) continue;
          rows.push({
            SourceId: Number(x.Id || x.ID || 0),
            Title: title,
            DP_Typ: String(x[f.typ] || ''),
            DP_Daten: String(x[f.daten] || '')
          });
        }
        url = String(data['@odata.nextLink'] || data?.d?.__next || '');
      }
      rows.sort((a, b) => String(a.Title).localeCompare(String(b.Title)));
      return rows;
    };

    const dp30ahSlotFileName = (now: number): string => {
      const slot = new Date(Math.floor(now / dp30ahIntervalMs) * dp30ahIntervalMs);
      const stamp = slot.toISOString().replace(/:/g, '-').replace(/\.\d{3}Z$/, 'Z');
      return `DP_Data_${stamp}.json`;
    };

    const dp30ahUpload = async (fileName: string, jsonText: string): Promise<void> => {
      const url = `${dp30ahListApi(dp30ahLibrary)}/RootFolder/Files/Add(url='${dp30ahEsc(fileName)}',overwrite=true)`;
      await dp30ahPost(url, jsonText, { 'Content-Type': 'application/json; charset=utf-8' });
    };

    const dp30ahCleanup = async (now: number): Promise<void> => {
      const data = await dp30ahGet(`${dp30ahListApi(dp30ahLibrary)}/RootFolder/Files?$select=Name,TimeCreated,ServerRelativeUrl&$top=5000`);
      const files: any[] = Array.isArray(data.value) ? data.value : [];
      const cutoff = now - dp30ahRetentionMs;
      for (const file of files) {
        const name = String(file.Name || '');
        if (!name.startsWith('DP_Data_') || !name.endsWith('.json')) continue;
        const created = Date.parse(String(file.TimeCreated || '')) || 0;
        if (!created || created > cutoff) continue;
        const rel = String(file.ServerRelativeUrl || '');
        if (!rel) continue;
        try {
          await dp30ahPost(`${dp30ahWebUrl()}/_api/web/getfilebyserverrelativeurl('${dp30ahEsc(rel)}')`, undefined, { 'X-HTTP-Method': 'DELETE', 'IF-MATCH': '*' });
        } catch (e) {
          console.warn('030AH: alte Backup-Datei konnte nicht gelöscht werden:', name, e);
        }
      }
    };

    const dp30ahDoBackup = async (reason: string): Promise<void> => {
      const now = Date.now();
      await dp30ahEnsureLibrary();
      const rows = await dp30ahLoadLiveRows();
      if (!rows.length) throw new Error('DP_Data enthält keine produktiven DP|-Datensätze.');
      const capturedAt = new Date(now).toISOString();
      const payload = JSON.stringify({
        format: 'DispoLuxBackup',
        formatVersion: 1,
        build: 'DLB-030AH-1.12.1.27',
        capturedAt,
        reason,
        sourceList: dp30ahDataList,
        recordCount: rows.length,
        retentionHours: 54,
        intervalMinutes: 30,
        rows
      }, null, 2);
      const fileName = dp30ahSlotFileName(now);
      await dp30ahUpload(fileName, payload);
      dp30ahLastSuccess = now;
      dp30ahWarn('');
      dp30ahWindow.__DISPOLUX_BACKUP_STATUS = { ok: true, capturedAt, fileName, recordCount: rows.length, reason };
      try { await dp30ahCleanup(now); } catch (e) { console.warn('030AH: Backup-Aufbewahrung konnte nicht vollständig bereinigt werden.', e); }
      console.info(`DispoLux Backup ${fileName}: ${rows.length} Datensätze · ${reason}`);
    };

    const dp30ahBackup = (reason: string): Promise<void> => {
      dp30ahQueue = dp30ahQueue.catch(() => undefined).then(async (): Promise<void> => {
        try {
          await dp30ahDoBackup(reason);
        } catch (e) {
          const msg = String((e as any)?.message || e || 'unbekannter Fehler');
          dp30ahWindow.__DISPOLUX_BACKUP_STATUS = { ok: false, failedAt: new Date().toISOString(), reason, message: msg };
          dp30ahWarn('DATENSICHERUNG FEHLGESCHLAGEN – ' + msg);
          console.error('030AH DispoLux Dateisicherung', e);
          throw e;
        }
      });
      return dp30ahQueue;
    };

    const dp30ahCloseBackup = (): void => {
      const now = Date.now();
      if (now - dp30ahLastCloseKick < 5000) return;
      dp30ahLastCloseKick = now;
      dp30ahBackup('Schließen/Verlassen').catch(() => undefined);
    };

    dp30ahWindow.dpDispoLuxBackupNow = (): Promise<void> => dp30ahBackup('Manuell');
    dp30ahWindow.dpDispoLuxBackupStatus = (): any => dp30ahWindow.__DISPOLUX_BACKUP_STATUS || {
      ok: null,
      openedAt: new Date(dp30ahOpenedAt).toISOString(),
      lastSuccess: dp30ahLastSuccess ? new Date(dp30ahLastSuccess).toISOString() : null
    };

    // Beim Öffnen nur die Bibliothek vorbereiten; erster Snapshot nach 30 Minuten.
    dp30ahEnsureLibrary().catch((e: unknown) => {
      const msg = String((e as any)?.message || e || 'unbekannter Fehler');
      dp30ahWarn('DATENSICHERUNG NICHT BEREIT – ' + msg);
      console.error('030AH Backup-Bibliothek', e);
    });

    const dp30ahFirstTimer = window.setTimeout(() => {
      dp30ahBackup('30-Minuten-Intervall').catch(() => undefined);
      const timer = window.setInterval(() => {
        dp30ahBackup('30-Minuten-Intervall').catch(() => undefined);
      }, dp30ahIntervalMs);
      Object.defineProperty(dp30ahWindow, '__DISPOLUX_FILE_BACKUP_030AH_TIMER', { value: timer, writable: true, configurable: true });
    }, dp30ahIntervalMs);
    Object.defineProperty(dp30ahWindow, '__DISPOLUX_FILE_BACKUP_030AH_FIRST_TIMER', { value: dp30ahFirstTimer, writable: true, configurable: true });

    // Browser-Schließen ist nicht erzwingbar: hidden startet früh, pagehide ist die zweite Chance.
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        dp30ahCloseBackup();
      } else if (Date.now() - dp30ahOpenedAt >= dp30ahIntervalMs && (!dp30ahLastSuccess || Date.now() - dp30ahLastSuccess >= dp30ahIntervalMs)) {
        dp30ahBackup('Rückkehr nach Pause').catch(() => undefined);
      }
    });
    window.addEventListener('pagehide', () => dp30ahCloseBackup());
  }
  /* DP_DLB_030AH_1_12_1_27_BACKUP_30MIN_FILES_END */


    const frame = document.createElement('iframe');
    frame.title = 'DispoPilot Online V1.3';
    frame.style.cssText = 'width:100%;height:calc(100vh - 150px);min-height:760px;border:0;border-radius:10px;background:#f3f5f7;display:block';
    host.appendChild(frame);
    frame.addEventListener('load', () => {
      const win = frame.contentWindow;
      const doc = frame.contentDocument;
      if (!win || !doc) { this.showError('Iframe-Kontext konnte nicht geöffnet werden.'); return; }
      void bootDispoPilot(win, doc, {
        webUrl: this.context.pageContext.web.absoluteUrl,
        userDisplayName: this.context.pageContext.user.displayName || '',
        userEmail: this.context.pageContext.user.email || ''
      }).catch((e: unknown) => {
        const msg = e instanceof Error ? e.message : String(e);
        console.error('DispoPilot boot error', e);
        this.showError(msg);
      });
    }, { once: true });
    frame.srcdoc = staticHtml;
  }

  private showError(message: string): void {
    this.domElement.innerHTML = '<div style="padding:16px;border:1px solid #fecaca;background:#fef2f2;color:#991b1b;border-radius:10px"><strong>DispoPilot konnte nicht gestartet werden.</strong><br>' + this.escapeHtml(message) + '</div>';
  }

  private escapeHtml(value: string): string {
    return value.replace(/[&<>"']/g, (c: string) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c] || c));
  }
}
