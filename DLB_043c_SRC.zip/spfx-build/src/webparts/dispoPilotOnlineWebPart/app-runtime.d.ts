export const staticHtml: string;
export function bootDispoPilot(win: Window, doc: Document, config: { webUrl: string; userDisplayName: string; userEmail: string }): Promise<void>;
